package com.example.puso_malaya

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
